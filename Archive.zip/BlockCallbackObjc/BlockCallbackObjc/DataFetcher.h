//
//  DataFetcher.h
//  BlockCallbackObjc
//
//  Created by steve on 2016-05-23.
//  Copyright © 2016 steve. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataFetcher : NSObject
- (void)fetchDataWithCompletionHandler:(void(^)(NSString *))handler;
@end
