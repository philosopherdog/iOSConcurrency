//
//  DetailViewController.m
//  Concurrency
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic) UIActivityIndicatorView *activityIndicator;
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self loadImage];

    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}

- (void)loadImage {
    [self activityIndicatorAnimate:YES];
    
    
//    dispatch_queue_t bgQ = dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0);
//    dispatch_async(bgQ, ^{
//        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://dl.dropboxusercontent.com/u/580418/1.jpg"]];
//        dispatch_async(dispatch_get_main_queue(), ^{
//            UIImage *image = [UIImage imageWithData:data];
//            self.imageView.image = image;
//            [self activityIndicatorAnimate:NO];
//        });
//    });
    
    NSOperationQueue *bgQ2 = [[NSOperationQueue alloc] init];
    NSBlockOperation *block = [NSBlockOperation blockOperationWithBlock:^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://dl.dropboxusercontent.com/u/580418/1.jpg"]];
        NSOperationQueue *mainQ = [NSOperationQueue mainQueue];
        NSBlockOperation *block2 = [NSBlockOperation blockOperationWithBlock:^{
            UIImage *image = [UIImage imageWithData:data];
            self.imageView.image = image;
            [self activityIndicatorAnimate:NO];
        }];
        [mainQ addOperation:block2];
    }];
    [bgQ2 addOperation:block];
}

- (void)activityIndicatorAnimate:(BOOL)animate {
    if (!self.activityIndicator) {
        self.activityIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        self.activityIndicator.color = [UIColor purpleColor];
        self.activityIndicator.center = self.view.center;
        self.activityIndicator.hidesWhenStopped = YES;
        [self.view addSubview:self.activityIndicator];
        [self.view bringSubviewToFront:self.activityIndicator];
    }
    animate ? [self.activityIndicator startAnimating] : [self.activityIndicator stopAnimating];
}


@end
