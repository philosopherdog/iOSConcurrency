//
//  MasterViewController.m
//  Concurrency
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import "MasterViewController.h"

@interface MasterViewController ()

@end

@implementation MasterViewController


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
}


@end
