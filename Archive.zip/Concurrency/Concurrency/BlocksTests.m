//
//  BlocksTests.m
//  Concurrency
//
//  Created by steve on 2016-05-26.
//  Copyright © 2016 steve. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "MasterViewController.h"

@interface BlocksTests : XCTestCase

@end

typedef NSNumber *(^MyBigNumberBlock) (NSNumber *, NSNumber *);

@implementation BlocksTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testSimpleBlockLiteral {
    ^ {
        NSLog(@"SIMPLE BLOCK LITERAL");
    }();
}

- (void)testTypeDef {
    typedef NSString * (^SayHelloBlock) (NSString *, NSString *);
    SayHelloBlock block = ^NSString * (NSString *first, NSString *last) {
        return [NSString stringWithFormat:@"%@ say hello to %@", first, last];
    };
    NSString *result = block(@"Jane",@"Ian");
    XCTAssertTrue([result isEqualToString:@"Jane say hello to Ian"]);
}

- (void)testBlockCallBack {
    __block NSNumber *result;
    [self someMethodWithBlock:^NSNumber *(NSNumber *n1, NSNumber *n2) {
        result = @([n1 intValue] * [n2 intValue]);
        return result;
    }];
    XCTAssertTrue([result isEqualToNumber:@4]);
}

- (void)someMethodWithBlock:(NSNumber *(^)(NSNumber *, NSNumber *))block {
    block(@2,@2);
}

- (void)testBlockCallBackWithTypeDef {
    __block NSNumber *result;
    [self someMethodWithBlock:^NSNumber *(NSNumber *n1, NSNumber *n2) {
        result = @([n1 intValue] * [n2 intValue]);
        return result;
    }];
    XCTAssertTrue([result isEqualToNumber:@4]);
}




@end
