//
//  MasterViewController.h
//  Concurrency
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UIViewController
@property (nonatomic, copy) void(^block)(void);
@end
