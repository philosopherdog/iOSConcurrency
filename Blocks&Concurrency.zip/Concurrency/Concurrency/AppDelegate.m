//
//  AppDelegate.m
//  Concurrency
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
