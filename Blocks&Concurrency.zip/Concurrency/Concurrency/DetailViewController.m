//
//  DetailViewController.m
//  Concurrency
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic) UIActivityIndicatorView *activityIndicator;
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadImage];
}

- (void)loadImage {
    [self activityIndicatorAnimate:YES];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://dl.dropboxusercontent.com/u/580418/1.jpg"]];
    UIImage *image = [UIImage imageWithData:data];
    self.imageView.image = image;
    [self activityIndicatorAnimate:NO];
}

- (void)activityIndicatorAnimate:(BOOL)animate {
    if (!self.activityIndicator) {
        self.activityIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        self.activityIndicator.color = [UIColor purpleColor];
        self.activityIndicator.center = self.view.center;
        self.activityIndicator.hidesWhenStopped = YES;
        [self.view addSubview:self.activityIndicator];
        [self.view bringSubviewToFront:self.activityIndicator];
    }
    animate ? [self.activityIndicator startAnimating] : [self.activityIndicator stopAnimating];
}


@end
