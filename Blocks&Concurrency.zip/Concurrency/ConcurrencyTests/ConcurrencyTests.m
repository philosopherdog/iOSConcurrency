//
//  ConcurrencyTests.m
//  ConcurrencyTests
//
//  Created by steve on 2016-05-24.
//  Copyright © 2016 steve. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ConcurrencyTests : XCTestCase

@end

@implementation ConcurrencyTests

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testSyncOnConcurrentQ {
    dispatch_queue_t backgroundQ = dispatch_get_global_queue(QOS_CLASS_USER_INTERACTIVE, 0);
    dispatch_sync(backgroundQ, ^{
        printf("1\n");
    });
    dispatch_sync(backgroundQ, ^{
        printf("2\n");
    });
    printf("3\n");
}

- (void)testAsyncOnUserCreatedSerialQ {
    dispatch_queue_t backgroundQ = dispatch_queue_create("com.lighthouse.concurrency.2", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(backgroundQ, ^{
        printf("4\n");
    });
    printf("5\n");
    
    dispatch_async(backgroundQ, ^{
        printf("6\n");
    });
    
    printf("7\n");
}

- (void)testSyncOnUserCreatedConcurrentQ {
    dispatch_queue_t backgroundQ = dispatch_queue_create("com.lighthouse.concurrency.3", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_sync(backgroundQ, ^{
        printf("4\n");
    });
    printf("5\n");
    
    dispatch_sync(backgroundQ, ^{
        printf("6\n");
    });
    
    printf("7\n");
}

- (void)testDispatchOnce {
    
    static dispatch_once_t onceToken;
    __block int num = 0;
    
    void (^block)(void) = ^ {
        num += 1;
        printf("8 is %d\n", num);
    };
    
    dispatch_once(&onceToken, block);
    
    XCTAssertTrue(num == 1);
    
    dispatch_once(&onceToken, block);
    
    XCTAssertFalse(num == 2);
}

// NSOperationQueue

- (void)testAddExecutionBlock {
    NSOperationQueue *backgroundQ = [[NSOperationQueue alloc] init];
    // optional settings
    backgroundQ.maxConcurrentOperationCount = 100;
    backgroundQ.qualityOfService = NSQualityOfServiceUserInitiated;
   // NSOperationQueue needs an NSOperation subclass to run
    NSBlockOperation *block = [NSBlockOperation blockOperationWithBlock:^{
        NSLog(@"==>> %s", __PRETTY_FUNCTION__);
    }];
    [block addExecutionBlock:^{
        NSLog(@"==>> %s", __PRETTY_FUNCTION__);
    }];
    [backgroundQ addOperation:block];
}

- (void)testCurrentQIsTheMainQ {
    // prove the current queue is the main queue
    NSOperationQueue *mainQ = [NSOperationQueue mainQueue];
    XCTAssertTrue([mainQ isEqual:[NSOperationQueue currentQueue]]);
}

- (void)testBackgroundQIsNotTheMainQ {
    NSOperationQueue *backgroundQ = [[NSOperationQueue alloc] init];
    XCTAssertFalse([backgroundQ isEqual:[NSOperationQueue mainQueue]]);
}

- (void)testOperationQueueDependency {
    typedef NS_ENUM(NSUInteger, Order) {
        OrderUndetermined,
        OrderFirst,
        OrderSecond,
    };
    
    __block Order order = OrderUndetermined;
    
    NSOperationQueue *backgroundQ = [[NSOperationQueue alloc] init];
    NSBlockOperation *blockOperation1 = [NSBlockOperation blockOperationWithBlock:^{
        printf("===>>> first block\n");
        if (order == OrderUndetermined) {
            order = OrderFirst;
        }
    }];
    NSBlockOperation *blockOperation2 = [NSBlockOperation blockOperationWithBlock:^{
        printf("===>>> second block\n");
        if (order == OrderUndetermined) {
            order = OrderSecond;
        }
    }];
    [blockOperation1 addDependency:blockOperation2];
    // adding multiple operations
    [backgroundQ addOperations:@[blockOperation1, blockOperation2] waitUntilFinished:YES];
    XCTAssertTrue(order == OrderSecond, @"blockOperation1 should depend on blockOperation2, and should only run after blockOperation2 runs");
}


@end
