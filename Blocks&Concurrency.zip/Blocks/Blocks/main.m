//
//  main.m
//  Blocks
//
//  Created by steve on 2016-05-23.
//  Copyright © 2016 steve. All rights reserved.
//

#import <Foundation/Foundation.h>

void captureByValue();
void captureByReference();
void captureAndMutate();

int main() {
    
    ^ {
        NSLog(@"simple block literal");
    }();
    
    
    void (^simpleBlock) (void);
    simpleBlock = ^ void (void) {
        NSLog(@"simple named block");
    };
    
    simpleBlock();
    
    simpleBlock = ^ {
        NSLog(@"simple named block showing inferred return and param type");
    };
    
    simpleBlock();
    
    // adding them to a collection
    
    NSArray *arr = @[^{NSLog(@"Yo");} ,^{NSLog(@"Mo");}];
    
    for (void(^item)(void) in arr) {
        item();
    }
    
    /*
    using return type and params
    */
    
    double (^multiplyTwoNums) (double, double);
    
    multiplyTwoNums = ^double (double a, double b) {
        return a * b;
    };
    
    double result1 = multiplyTwoNums(10, 10);
    NSLog(@"multiplyTwoNums result: %@", @(result1));
    
    ^double (double a, double b) {
        double result = a * b;
        NSLog(@"executing literal with params, result: %@", @(result));
        return result;
    }(10, 20);
    
    
    NSString *(^sayHello)(NSString*, NSString*) = ^NSString*(NSString *firstName, NSString *lastName) {
        return [NSString stringWithFormat:@"hello %@ %@", firstName, lastName];
    };
    
    NSString *result2 = sayHello(@"John", @"Doe");
    NSLog(@"%@", result2);
    
    // Capturing value
    
    captureByValue();
    captureByReference();
    captureAndMutate();
    
    // looping through array using enumerateObjectsUsingBlock
    
    NSArray *arr2 = @[@1,@2,@3,@4,@5];
    
    
    // looping through dictionary using enumerateKeysAndObjectsUsingBlock
    NSDictionary *dict = @{@1 : @"one", @2 : @"two", @3 : @"three", @4 : @"four"};
    
    
    return 0;
}

// C functions
void captureByValue() {
    int num = 24;
    void (^capturer)(void) = ^{
        NSLog(@"first captured value: %@", @(num));
    };
    // NB. the block captures by value, not reference
    num = 48;
    capturer();
}

void captureByReference() {
    __block int num = 24;
    
    void (^capturer)(void) = ^{
        NSLog(@"second captured value: %@", @(num));
    };
    // NB. captured by reference
    num = 48;
    capturer();
}

void captureAndMutate() {
    __block int num = 10;
    
    void (^capturer)(void) = ^ {
        num += 20;
    };
    capturer();
    NSLog(@"captured value is now %@", @(num));
}







