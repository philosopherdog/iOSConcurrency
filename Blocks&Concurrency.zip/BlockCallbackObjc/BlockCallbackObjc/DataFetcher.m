//
//  DataFetcher.m
//  BlockCallbackObjc
//
//  Created by steve on 2016-05-23.
//  Copyright © 2016 steve. All rights reserved.
//

#import "DataFetcher.h"

@interface DataFetcher()
@property (nonatomic, copy) void (^completionHandler)(NSString *);
@end

@implementation DataFetcher
- (void)fetchDataWithCompletionHandler:(void(^)(NSString *))handler {
    self.completionHandler = handler;
    [self performSelector:@selector(executeCompletionHandler) withObject:self afterDelay:5.0];
}

- (void)executeCompletionHandler {
    self.completionHandler(@"some passed back data!");
}

@end
