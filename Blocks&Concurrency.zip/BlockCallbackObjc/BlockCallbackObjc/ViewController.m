//
//  ViewController.m
//  BlockCallbackObjc
//
//  Created by steve on 2016-05-23.
//  Copyright © 2016 steve. All rights reserved.
//

#import "ViewController.h"
#import "DataFetcher.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *fetchDataButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)fetchDataTapped:(UIBarButtonItem *)sender {
    DataFetcher *fetcher = [DataFetcher new];
    [self.activityIndicator startAnimating];
    self.fetchDataButton.enabled = NO;
    [fetcher fetchDataWithCompletionHandler:^(NSString *passedBackData){
        [self.activityIndicator stopAnimating];
        self.fetchDataButton.enabled = YES;
        NSLog(@"passed back: %@", passedBackData);
    }];
}

@end
