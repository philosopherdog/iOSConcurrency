//
//  AppDelegate.h
//  BlockCallbackObjc
//
//  Created by steve on 2016-05-23.
//  Copyright © 2016 steve. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

